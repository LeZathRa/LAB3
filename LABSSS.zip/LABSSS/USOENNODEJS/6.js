let nombreCompleto = "Juan Perez";
let nombrecompleto = "Carlos Lara";
console.log( nombreCompleto );
console.log( nombrecompleto);

let a1nombreCompleto;
let _nombreCompleto;
let $nombreCompleto;

let ruptura = 10;