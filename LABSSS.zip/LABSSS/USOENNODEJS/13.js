let vacaciones = false, diaDescanso = true;
if( vacaciones || diaDescanso ){
console.log("Padre puede asistir al juego del hijo");
}
else{
console.log("El padre está ocupado");
} 