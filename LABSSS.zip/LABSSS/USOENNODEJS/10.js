let a = 3, b = 2, c = "3";

let z = a == c;
console.log(z);

z = a === c;
console.log(z);