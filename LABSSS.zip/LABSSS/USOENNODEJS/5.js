let nombre;
nombre = "Juan";
console.log( nombre );

const apellido = "Perez";