let a = 3, b = 2;
let z = a + b;

z=++a;
console.log(a);
console.log(z);

z= b++;
console.log(b);
console.log(z);

z = --a;
console.log(a);
console.log(z);

z= b--;
console.log(b);
console.log(z);