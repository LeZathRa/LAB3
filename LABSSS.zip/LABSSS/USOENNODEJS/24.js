miFuncion(4,2);

function miFuncion( a , b ){
    console.log("Suma: " + ( a + b ))
}

miFuncion(2,3);