var nombre = "Carlos";
console.log(nombre);

var numero = 1000;
console.log(numero);

var objeto = {
    nombre : "Juan",
    apellido : "Perez",
    telefono : "55443322"
}
console.log(objeto)