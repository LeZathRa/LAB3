for(let contador=0;contador<3;contador++){
    console.log(contador);
}
console.log("Fin ciclo for")