
let a = 15;
let valMin=0, valMax=10;
if( a >= valMin && a <= valMax ){ console.log("Dentro de rango");
}
else{
console.log("Fuera de rango");
} 