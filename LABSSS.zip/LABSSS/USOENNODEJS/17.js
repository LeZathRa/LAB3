let contador = 0;
while(contador <3){
    console.log(contador);
    contador++;
}
console.log("Fin ciclo While")