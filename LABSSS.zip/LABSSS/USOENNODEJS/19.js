const autos=['BMW','Mercedes Benz','Volvo'];
console.log(autos);